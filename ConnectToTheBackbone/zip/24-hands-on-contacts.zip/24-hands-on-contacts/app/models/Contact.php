<?php

class Contact extends Eloquent {
	public $table = 'contacts';
	public $timestamps = false;
}