<?php

return array(
	array(
		'first_name' => 'John',
		'last_name'  => 'Doe',
		'email_address' => 'john@example.com',
		'description' => 'My best friend.'
	),
	array(
		'first_name' => 'Jane',
		'last_name'  => 'Doe',
		'email_address' => 'jane@example.com',
		'description' => 'My best friend\'s wife.'
	),
	array(
		'first_name' => 'Jeffrey',
		'last_name'  => 'Way',
		'email_address' => 'jeffrey@envato.com',
		'description' => 'Not sure why I have myself as a contact, but okay.'
	)
);